package com.codeoftheweb.salvo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalvoApplicationTests {

	@Test
	void contextLoads() {
	}

}
